---
name: greetings
description: Friendly greetings
---
A greeting from a zip.
